Hello and thank you for purchasing Low Poly Buildings Pack 2 package.

There are 10 fbx files all made to prefabs.
Texures are 512*512 png combined to mobile/diffuse material.

Tris count range from 292 to 888.