Hello and thank you for purchasing Low Poly Buildings Suburb package.

There are 16 fbx files all made to prefabs. 29 prefabs in total.
Texures are 512*512 png combined to mobile/diffuse material.

Tris count range from 550 to 997.