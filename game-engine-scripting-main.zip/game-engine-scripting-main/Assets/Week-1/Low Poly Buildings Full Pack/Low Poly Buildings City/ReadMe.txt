Hello and thank you for purchasing Low Poly Buildings Suburb package.

There are 40 fbx files all made to prefabs. 77 prefabs in total.
Texures are 512*512 png.

Tris count range from 204 to 4044.