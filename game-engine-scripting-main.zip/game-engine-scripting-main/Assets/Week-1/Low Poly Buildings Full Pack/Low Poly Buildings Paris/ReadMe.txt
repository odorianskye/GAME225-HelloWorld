Hello and thank you for purchasing Low Poly Buildings Paris package.

There are 18 fbx files all made to prefabs.
Texures are 512*512 png combined to mobile/diffuse material.

Tris count range from 252 to 640


https://www.facebook.com/SunnySIdeDevelope