There is 1 fbx file made to 9 prefabs in total.
Characters are setup to work with Mecanim (no animations included in this pack)
Texures are 512*512 png.